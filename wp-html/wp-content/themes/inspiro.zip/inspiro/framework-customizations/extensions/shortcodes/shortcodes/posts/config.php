<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Blog Posts', 'fw' ),
	'description' => __( 'Display Latest Blog Posts', 'fw' ),
	'tab'         => __( 'Inspiro', 'fw' ),
);