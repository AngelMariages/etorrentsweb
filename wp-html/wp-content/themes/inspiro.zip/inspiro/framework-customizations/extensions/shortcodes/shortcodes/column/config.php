<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'tab'         => __('Layout Elements', 'fw'),
		'title'       => __('Column', 'fw'),
		'popup_size'  => 'small',
		'type'        => 'column'
	)
);