<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Pricing Table', 'fw' ),
	'tab'         => __( 'Inspiro', 'fw' ),
);