<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Portfolio Gallery', 'fw' ),
	'description' => __( 'Add a few portfolio posts', 'fw' ),
	'tab'         => __( 'Inspiro', 'fw' ),
);