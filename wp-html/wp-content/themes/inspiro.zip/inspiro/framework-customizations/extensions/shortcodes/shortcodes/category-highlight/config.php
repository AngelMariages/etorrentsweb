<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Featured Content', 'fw' ),
	'description' => __( 'Feature a Category or a Page', 'fw' ),
	'tab'         => __( 'Inspiro', 'fw' )
);