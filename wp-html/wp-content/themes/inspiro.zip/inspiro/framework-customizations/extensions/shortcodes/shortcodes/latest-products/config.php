<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'WooCommerce Products', 'fw' ),
	'description' => __( 'Display WooCommerce Products', 'fw' ),
	'tab'         => __( 'Inspiro', 'fw' ),
);